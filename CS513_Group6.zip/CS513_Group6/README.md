# CS513 Fall2022 Group6

# AIRLINE PASSENGER SATISFACTION

1. Shivang Medhekar (smedheka@stevens.edu)
2. Mingfang Liang (mliang8@stevens.edu)
3. Yutong Wei (ywei42@stevens.edu)
4. Jiani Yu (jyu42@stevens.edu)

Use requirements.txt to install all dependencies for the project
Models that take time to train are saved
If you want to check by training the model, pass mode='train' in the get function for the model